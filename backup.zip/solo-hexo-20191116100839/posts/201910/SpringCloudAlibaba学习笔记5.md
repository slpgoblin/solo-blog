title: Spring Cloud Alibaba 学习笔记 5
date: '2019-10-26 12:34:30'
updated: '2019-10-26 12:34:30'
tags: [JAVA, 笔记]
permalink: /articles/2019/10/26/1572064470597.html
---
## 根据api文档开发详情接口
详情接口api：

| 字段 | 描述 | 类型 |
| :-: | :-: | :-: |
| **auditStatus** *optional* | 审合状态 | auditStatus |
| **author**  *optional* |  作者 |  string |
| **buyCount**  *optional* |  购买次数 |  integer (int32) |
| **cover**  *optional* |  封面地址 |  string |
| **createTime**  *optional* |  创建时间 |  string (date-time) |
| **downloadUrl**  *optional* |  下载地址 |  string |
| **id**  *optional* |  id |  integer (int32) |
| **isOriginal**  *optional* |  是否原创 |  boolean|
| **price**  *optional* |  价格 |  integer (int32) |
| **reason**  *optional* |  审核不通过的原因|  string |
| **show**  *optional*|  是否展示 |  boolean |
| **summary**  *optional* | 简介 |  string |
| **title**  *optional* |  标题 |  string |
| **type**  *optional* |  类型（分类）|  string |
| **updateTime**  *optional* |  修改时间 |  string (date-time)|
| **wxNickname**  *optional* |  发布人昵称 |  string|

由于进行了服务拆分，内容中心和用户中心是分别连的不同数据库，而api中 *发布人昵称* 字段是要从用户中心获取，其他字段则是在用户中心获取。

所以有两个接口，在内容中心的api中去调用用户中心的api获取发布人昵称，再整合内容中心的其他字段统一整合给前端。

这里使用RestTemplate进行交互：
```
// 发布人id
        Integer userId = share.getUserId();

        UserDTO userDTO = restTemplate.getForObject("http://127.0.0.1:8080/users/{id}",UserDTO.class,userId);
```
使用此种方式可以实现功能但是存在以下弊端：
* 服务地址发生变化怎么办？
* 如何实现负载均衡？
* 用户中心宕机怎么?
