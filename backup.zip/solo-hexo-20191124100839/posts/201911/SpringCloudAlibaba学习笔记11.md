title: Spring Cloud Alibaba 学习笔记 11
date: '2019-11-03 23:52:06'
updated: '2019-11-11 23:53:26'
tags: [待分类]
permalink: /articles/2019/11/03/1572796326475.html
---
# Nacos服务端介绍

## 服务发现的领域模型

### 什么是领域模型

个人理解nacos的领域模型就是nacos的作用域，比如说，

### 领域模型有哪些，作用是什么

namespace命名空间。开发测试生产
group服务分组。不同的服务可以分到一个组，默认分组DEFAULT_GROUP(Spring Cloud Alibaba0.9.0没有使用group)
service微服务
cluster集群。北京机房，上海机房
instance实例。

### 如何配置领域模型

## 元数据

### 什么是元数据

[官方文档](https://nacos.io/zh-cn/docs/concepts.html)

级别：服务级别、集群级别、实例级别
### 元数据的作用
* 提供描述信息
* 让微服务调用更加灵活：v1版本调用v1版本的微服务，v2版本调用v2版本的微服务
### 如何配置元数据
* 服务端配置
* 配置文件指定
