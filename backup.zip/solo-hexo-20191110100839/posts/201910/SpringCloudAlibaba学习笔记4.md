title: Spring Cloud Alibaba 学习笔记 4
date: '2019-10-26 11:40:15'
updated: '2019-10-26 11:40:34'
tags: [JAVA, 笔记]
permalink: /articles/2019/10/26/1572061215294.html
---
# 项目工作流程
## Schema First
1. 分析业务（流程图、用例图...架构图等等）--> 建模业务，并且确定架构
2. 敲定业务流程（评审）
3. 设计API(我需要哪些API呢)/数据模型(表结构设计|类图|ER图等等)
4. 编写API文档
5. 编写代码
---
## API First
1. 分析业务（流程图、用例图...架构图等等）--> 建模业务，并且确定架构
2. 敲定业务流程（评审）
3. 设计API(我需要哪些API呢)/数据模型(表结构设计|类图|ER图等等)
4. 编写代码
5. 编写API文档
---
**以上两种方式灵活运用**

## 小程序设计
[小程序api文档](https://t.itmuch.com/doc.html)
[小程序前端代码](https://github.com/eacdy/itmuch-miniapp)
