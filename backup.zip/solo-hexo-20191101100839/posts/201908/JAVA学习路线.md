title: JAVA学习路线
date: '2019-08-17 13:29:23'
updated: '2019-08-20 20:05:16'
tags: [JAVA]
permalink: /articles/2019/08/17/1566019763425.html
---

![](https://img.hacpai.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 原因

博主做开发也有一段时间，由于工作比较忙，学习上已经荒废一段了。
看着琳琅满目的技术，也是无从下手，于是准备先整理一份贴近日常工作的知识体系，再给自己充电。
**本文中提到的视频以及图书仅作为博主的学习路，	并非最优推荐。
如下如：

![image.png](https://img.hacpai.com/file/2019/08/image-747bfb03.png)

## 学习路线

### 单机应用

* JAVA	
	* **视频** 码码在线、尚硅谷、尚学堂、马士兵
	* **图书** 《Head First JAVA》、《Effective Java》、阿里巴巴JAVA开发手册
* Servlet & JSP & JDBC
	* **视频** 码码在线、尚硅谷
	* **图书** 待补充
* Spring & SpringMVC & Mybatis
	* **视频** 码码在线、尚硅谷。
	* **图书** 待补充
* SpringBooot
	* **视频** 码码在线、[小马哥 - Java 微服务实践 - Spring Boot 系列](https://segmentfault.com/ls/1650000011063780)、[慕课网 - SpringBoot开发常用技术整合](https://www.imooc.com/learn/956)、
	* **图书** [Spring Boot 入门、进阶系列文章](http://www.spring4all.com/article/246)
* Redis
	* **视频** 码码在线、尚硅谷、[慕课网-Redis入门](https://www.imooc.com/learn/839)
	* **图书** 《Redis 开发与运维》
* MongoDB
	* **视频** 尚硅谷、[# 【小马技术】MongoDB 从入门到学会](https://www.bilibili.com/video/av24311263)
 	* **图书** 《MongoDB实战》
* 单机应用实战
	* **视频** 码码在线、[慕课网廖师兄 - Spring Boot 打造企业级微信点餐系统](https://coding.imooc.com/class/117.html)
	* **图书** 《Spring Boot 企业级应用开发实战》
### 微服务
* Spring Cloud
	* **视频** [《Java 微服务实践 - Spring Cloud 系列》](https://segmentfault.com/ls/1650000011386794?r=bPW6qc)
	* 图书 [方志朋 - 史上最简单的 SpringCloud 教程](https://blog.csdn.net/forezp/article/details/70148833)、《Spring Cloud微服务实战》
* 消息队列 - MQ
	* **视频** 马士兵 [《RocketMQ 视频》](https://www.bilibili.com/video/av11074519)、阿神 [《RabbitMQ 消息中间件极速入门与实战》](https://www.imooc.com/learn/1042)
	* **图书** [《阿里云 —— 消息队列 MQ》](https://help.aliyun.com/product/29530.html?spm=a2c4g.11186623.6.540.68cc5b3aZYDU2Y)、[《RabbitMQ 实战指南》](https://union-click.jd.com/jdc?d=mmamvo)
* 微服务实战
	* **视频** 码码在线、[《Spring Cloud 微服务实战视频课程》](https://www.bilibili.com/video/av24536999)
	* **图书** 待补充

### 中间件
* 定时任务
	* 说明 单机定时任务Quartz、分布式定时任务Elastic-Job
	* **视频** 
* 搜索引擎
	* 待补充
* 分库分表
	* 待补充
* 分布式事务
	* 待补充
* 日志组件
	* 待补充

### 工具

* Maven
	* **说明** 会用即可，可以看文章，或者项目视频中会带有一些使用说明。
* Git
	* **说明** 极客时间的Git教程、[Git官方教程](https://git-scm.com/book/zh/v2)
* Jenkins
	* **说明** 会用即可。教程待补充。

### 运维
* Linux
	* **说明** 学会常用命令即可。教程待补充。
	
* Docker
	* **说明** 学会大概操作即可。教程待补充。
* kubernetes	
	* **说明** 同Docker。
### 底层

* JAVA并发
	* **视频** 码码在线、尚硅谷[《Java 并发视频教程全集》](https://www.bilibili.com/video/av59548640/?pikaqiu)
	* **图书** [《Java 并发编程实战》](https://union-click.jd.com/jdc?d=x2yrwq)、[《Java 并发编程的艺术》](https://u.jd.com/gpkonU)
* Netty
	* **视频** [《尚硅谷 - NIO 视频教程全集》](https://www.bilibili.com/video/av59543731/?pikaqiu)
	* **图书** [掘金小册 -《Netty 入门与实战：仿写微信 IM 即时通讯系统》](https://juejin.im/book/5b4bc28bf265da0f60130116?referrer=5904c637b123db3ee479d923)
* 设计模式
	* **视频** [慕课网 - Java设计模式精讲 Debug方式+内存分析](https://coding.imooc.com/class/270.html)
	* **图书** 《大话设计模式》、《Head First 设计模式》、[java 23种设计模式 深入理解](https://www.cnblogs.com/foryang/p/5849402.html)
* JVM
	* **视频** 尚硅谷
	* **图书** 《深入理解Java虚拟机：JVM高级特性与最佳实践(第2版) 》
* 数据结构 & 算法
	* **视频** 待补充
	* **图书** 极客学院 - 算法与数据结构之美
