title: Spring Cloud Alibaba 学习笔记 12 - 负载均衡
date: '2019-11-14 00:02:22'
updated: '2019-11-19 23:31:22'
tags: [JAVA, SpringCloud, Alibaba]
permalink: /articles/2019/11/14/1573660942393.html
---
# 负载均衡

## 负载均衡的两种方式

### 服务端负载均衡
通用做法是利用nginx实在服务端负载均衡，即请求到达nginx之后，由nginx实在算法来决定分发到哪个服务节点。

### 客户端负载均衡
客户端负载均衡就是说负载均衡算法由客户端来实现，例如：
服务A请求服务B，服务B由三个节点，在服务A请求之前通过负载均衡算法计算出要请求某个节点。

## 手动实现负载均衡

改造获取url的方法，在客户端利用随机数，随机获取服务端api的url，代码如下：
```
	//通过服务注册发现获取api地址
        List<ServiceInstance> userInstances = discoveryClient.getInstances("user-center");
        List<String> targetUrls = userInstances.stream()
            .map(userInstance -> userInstance.getUri().toString()+"/users/{id}")
            // 默认获取list中的第一条，如果list为空则抛出异常
            .collect(Collectors.toList());

        //随机数
        int i = ThreadLocalRandom.current().nextInt(targetUrls.size());

        String targetUrl = targetUrls.get(i);
        log.info("请求的目标url：{}",targetUrl);
```

## 使用Ribbon实现负载均衡

### Ribbon是什么

Ribbon是Netflix开源的客户端负载均衡组件。

Ribbon虽然只是一个工具类框架，它不像服务注册中心、配置中心、API网关那样需要独立部署，但是它几乎存在于每一个Spring Cloud构建的微服务和基础设施中。因为微服务间的调用，API网关的请求转发等内容，实际上都是通过Ribbon来实现的。

#### Ribbon的组成

| 接口 | 作用 | 默认值 |
| :-: | :-: | :-: |
| IClientConfig | 读取配置 | DefaultClientConfigImpl |
| IRule | 负载均衡规则，选择实例 | ZoneAvoidanceRule |
| IPing | 筛选掉ping不通过的实例 | DummyPing |
| ServerList<Server> | 交给Ribbon的实例列表 | **Ribbon**: ConfigurationBasedServerList<br>**Spring Cloud Alibaba**: NacosServerList |
| ServerListFileter<Server> | 过滤掉不符合条件的实例 | ZonePreferenceServerListFilter |
| ILoadBalancer | Ribbon的入口 | ZoneAwareLoadBalancer |
| ServerListUpdater | 更新交给Ribbon的List的策略 | PollingServerListUpdater |

#### Ribbon内置的负载均衡规则 

| 规则名称 | 特点 |
| :-: | :-: |
| AvailabilityFilterRule | 过滤掉一直链接失败的被标记为circuit tripped的后端server，并过滤掉那些高并发的后端Server或者使用一个AvailabilityPredicate来包含过滤server的逻辑，其实就是检查status里记录的各个server的运行状态 |
| BestAvailableRule | 选择一个最小的并发请求的server，逐个考察server，如果server被tripped了，则跳过 |
| RandomRule | 随机选择一个server |
| ResponseTimeWeightedRule | 已废弃、作用同WeightedResponseTimeRule |
| RetryRule | 对选定的负载均衡策略机上重试机制，在一个配置时间段内选择server不成功，则一直尝试使用subRule的方式选择一个可用的server |
| RoundRobinRule | 轮询选择，轮询index，选择index对应位置的server |
| WeightedResponseTimeRule | 根据相应时间加权，响应时间越长，权重越小，被选中的可能性降低 |
| ZoneAvoidanceRule | 符合判断Server所属Zone(区域)的性能和server的可用性选择server，在没有Zone的环境下，类似轮询(RoundRobinRule) |

### 引入Ribbon后的架构演进

### 整合Ribbon实现负载均衡

Nacos的服务发现组件中已经集成了Ribbon，所以不需要手动添加Ribbon依赖
1.在自定义restTemplate中添加注解
```
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }
```
2.改造请求用户中心的代码，改造后整体方法如下：
```
public ShareDTO findById(Integer id) {
        // 获取分享详情
        Share share = shareMapper.selectByPrimaryKey(id);
        // 发布人id
        Integer userId = share.getUserId();
        // 这里的user-center是
        UserDTO userDTO = restTemplate.getForObject("http://user-center/users/{userId}" ,UserDTO.class,userId);

        ShareDTO shareDTO = new ShareDTO();
        // 消息的装配
        BeanUtils.copyProperties(share, shareDTO);
        shareDTO.setWxNickname(userDTO.getWxNickname());
        return shareDTO;
    }
```

### 自定义配置Ribbon

1.新增Ribbon配置类
```
package com.goblin.contentcenter.config;

import config.ribbon.RibbonConfig;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Configuration;

@Configuration
@RibbonClient(name = "user-center",configuration = RibbonConfig.class)
public class UserConterRibbonConfig {
}
```
2.新增自定义规则配置
```
package config.ribbon;

import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.RandomRule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RibbonConfig {

    @Bean
    public IRule ribbonRule(){
        return new RandomRule();
    }
}
```

**注意**
这里的自定义规则类不能在启动类包或者子包下面，会出现父子上下文问题,详情参考[Spring父子容器问题](https://blog.csdn.net/qq_32588349/article/details/52097943)

也可以使用配置文件自定义规则:
```
user-center:
  ribbon:
    NFLoadBalancerRuleClassName: com.netflix.loadbalancer.RandomRule
```

### 最佳总结
* 尽量使用属性配置(属性配置优先级要高于代码配置，而且属性配置不需要编译、打包、重新发布)
* 在同一个微服务内尽量保持单一致，统一使用代码配置或者属性配置否则会增加排查问题的方式

### 全局配置

* 让ComponentScan上下文重叠（容易翻车）
* @RibbonClients(defaultConfiguration=xxx.class)

### 饥饿加载

ribbon默认是第一次执行之后才会创建ribbonClient，会造成第一次请求时间过长，添加如下配置会解决此问题，支持配置多个服务使用逗号分隔
```
ribbon:
  eager-load:
    enabled: true
    clients: user-center,xxx
```

### 自定义ribbon规则

由于ribbon自带的负载规则没有支持权重的，而nacos是可以在控制台为每个服务配置权重，这里自定义一个可以支持权重的rule

```
@Slf4j
public class NacosWeightedRule extends AbstractLoadBalancerRule {

    @Resource
    private NacosDiscoveryProperties nacosDiscoveryProperties;

    @Override
    public Server choose(Object o) {
        try {
            BaseLoadBalancer loadBalancer = (BaseLoadBalancer) this.getLoadBalancer();
            log.info("lb = {}",loadBalancer);
            // 想要请求的微服务名称
            String name = loadBalancer.getName();
            // 权重负载均衡算法，nacos自带
            NamingService namingService = nacosDiscoveryProperties.namingServiceInstance();
            Instance instance = namingService.selectOneHealthyInstance(name);
            log.info("选择的实例是：port = {}, instance = {}",instance.getPort(),instance);
            return new NacosServer(instance);
        } catch (NacosException e) {
            log.error("获取实例失败");
            return null;
        }
    }

    @Override
    public void initWithNiwsConfig(IClientConfig iClientConfig) {
        //读取配置文件，并初始化NacosWeightedRule，一般可以不用
    }
}
```
修改自定义配置，将规则改为自定义的rule
```
@Configuration
public class RibbonConfig {

    @Bean
    public IRule ribbonRule(){
        return new NacosWeightedRule();
    }
}
```


**疑问**
**为什么nacosClient自带了权重的负载均衡算法，那为什么还需要ribbon？**
为了遵循spring cloud 标准，spring-cloud-commons定义了标准，子项目spring-cloud-loadbalancer没有权重概念，但是ribbon符合此标准

### 扩展-同机房优先调用
