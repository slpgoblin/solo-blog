title: Spring Cloud Alibaba 学习笔记 10
date: '2019-10-30 09:12:01'
updated: '2019-11-03 23:33:35'
tags: [JAVA, SpringCloud, Alibaba, 笔记]
permalink: /articles/2019/10/30/1572397921649.html
---
## 集成Nacos

### 搭建Nacos服务端
[下载Nacos](https://github.com/alibaba/nacos/releases)

版本可以根据Spring Cloud Alibaba的依赖中寻找nacos客户端的版本，如下：
```
        <nacos.client.version>1.1.1</nacos.client.version>

```

由于nacos服务端没有1.1.1，所以我是用的版本是1.1.3

搭建Nacos服务端

[官方文档](https://nacos.io/zh-cn/docs/quick-start.html)

启动成功后访问http://127.0.0.1:8848/nacos

账号密码是：nacos/nacos

### 用户中心注册到Nacos

先添加服务注册发现依赖到pom文件：
```
	<dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
        </dependency>
```
然后在yml中添加配置：
```
spring:
  cloud:
    nacos:
      discovery:
	# nacos地址
        server-addr: 127.0.0.1:8848
  # 服务名，即serviceId
  application:
    name: user-center
```

### 内容中心注册到Nacos

操作同用户中心

但是需要将服务名改为内容中心
```
application:
        name: content-center
```

### 服务多实例

* 这里模拟一下服务多实例，即一个服务启动多个节点，以用户中心为例

需要在IDEA里面取消下图的Single instqance only勾选框
![image.png](https://img.hacpai.com/file/2019/11/image-9633dc63.png)

首先启动一个用户中心实例端口为8080，然后修改配置文件将端口改为9090，再次点击启动，两个实例都启动成功之后IDEA会显示有两个进程
![image.png](https://img.hacpai.com/file/2019/11/image-c4e3ed9d.png)


### 验证

#### 服务端验证

登录nacos服务端，在服务管理->服务列表中可以看到刚刚注册的服务,以及多实例：
![image.png](https://img.hacpai.com/file/2019/11/image-52fd0d76.png)

看到用户中心有两个实例，点击用户中心的详情可以看到具体的实例信息：
![image.png](https://img.hacpai.com/file/2019/11/image-75460443.png)

#### 程序验证

使用内容中心访问用户中心实例：

新建测试类，使用DiscoveryClient获取用户中心实例信息，效果如下图

```
@RestController
@RequestMapping("test")
public class TestController {

    @Resource
    private DiscoveryClient discoveryClient;

    @GetMapping("/getInstances")
    public List<ServiceInstance> getInstances() {
        // 获取用户信息实例
        return discoveryClient.getInstances("user-center");
    }
}
```


![image.png](https://img.hacpai.com/file/2019/11/image-a1f9ecc5.png)

### 程序使用

改造我们之前内容中心请求用户中心的代码：
```
//通过服务注册发现获取api地址
        List<ServiceInstance> userInstances = discoveryClient.getInstances("user-center");
        String targetUrl = userInstances.stream()
            .map(userInstance -> userInstance.getUri().toString()+"/users/{id}")
            // 默认获取list中的第一条，如果list为空则抛出异常
            .findFirst().orElseThrow(() -> new IllegalArgumentException("没有用户中心实例"));
        log.info("请求的目标url：{}",targetUrl);
        UserDTO userDTO = restTemplate.getForObject(targetUrl,UserDTO.class,userId);
```
然后访问接口，仍然可用。同时日志中也打印了对应的url。
```
2019-11-03 23:30:57.054  INFO 17368 --- [nio-8010-exec-1] c.g.c.service.content.ShareService       : 请求的目标url：http://192.168.56.28:9090/users/{id}
```
![image.png](https://img.hacpai.com/file/2019/11/image-26560de0.png)

