title: JAVA并发编程1
date: '2019-10-24 12:59:55'
updated: '2019-10-24 13:05:56'
tags: [JAVA, 并发编程, 多线程]
permalink: /articles/2019/10/24/1571893195215.html
---
	学习并发编程第一课
首先有一个类，功能是打印数字
```
public class Counter {
    private int count;
    public void add(){
        try {
            for (int i=0;i<10;i++){
                Thread.sleep(100);
                this.count++;//竞争条件
                System.out.println(" "+this.count);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
```
然后创建一个测试类，使用三个线程调用打印数字的方法，理想状态是打印到30，且没有重复。
```
public class Test {
    public static void main(String[] args) {
        Counter counter = new Counter();

        new Thread(new Runnable() {
            @Override
            public void run() {
                counter.add();
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                counter.add();
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                counter.add();
            }
        }).start();
    }
}
```
运行结果是：1 2 3 4 5 6 7 8 9 10 11 12 13 14 14 15 16 17 18 19 20 21 22 23 24 25 26 27 29 29
**显然没有成功打印1-30而且还有重复的输出**，这里就需要使用到并发场景的解决方案：
* 将synchronized关键字添加到方法上   public synchronized void add()   问题得以解决，但是这种方式大大的降低了效率，不可取！
* 用synchroniezd来修饰竞争工作项，注意：这里将下面的输出也给括了起来是为了将输出给同步起来，防止输出混乱！
```
synchronized (this){
　　　　this.count++;//竞争工作项
　　　　System.out.print(" "+this.count);
　　}
```
　　问题解决，效率要高于方案1  但是使用了synchroniezd的都是同步的，都是会影响效率的。
* 使用原子的int类  即AtomicInteger   这个东西是个类，需要new出来再用
　　将原来的`int count`改为`private AtomicInteger count = new AtomicInteger(0);`
　　然后coung++和输出改为`System.out.print(" "+count.incrementAndGet());//先增加在获取`
　　问题解决（输出有可能会乱序）  这说明原子类的操作没有像synchroized那样严格的排队式的操作，但是数据是正确的，效率较高！

**总结：**

	synchronized是一个内部锁，可重入锁。synchronized拥有强制原子性的内部锁机制，是一个可重入锁。在一个线程使用synchronized方法时调用该对象另一个synchronized方法，即一个线程得到一个对象锁后再次请求该对象锁，是永远可以拿到锁的。

	synchronized的一致性很强，可以防止线程不同步的问题，但是使用synchronized的话会降低效率。可以考虑使用原子类。

