title: Spring Cloud Alibaba 学习笔记 7
date: '2019-10-27 00:51:08'
updated: '2019-10-27 00:56:51'
tags: [JAVA, 笔记, SpringCloud, Alibaba]
permalink: /articles/2019/10/27/1572108668171.html
---
## 版本与兼容性
### Spring Cloud版本命名
* Spring Boot的版本命名（多数版本命名都如此）
```
	<!--语义化版本控制-->
        <!--2：主版本，第几代-->
        <!--1：次版本，一些功能的添加，但是架构没有太大变化，是兼容的-->
        <!--5：增量版本，bug修复-->
        <!--RELEASE：里程碑，SNAPSHOT:开发版 M：里程碑 RELEASE: 正式版本-->
        <version>2.1.5.RELEASE</version>
```
* Spring Cloud版本采用伦敦地铁站站名来命名，称之为release train（发布列车），这样做的原因是为了避免混淆，因为Spring Cloud的子项目太多。
* Greenwich SR3：这个版本代表Greenwich的第三个bug修复版本。SR(Service Release)

[Spring Cloud的版本命名](https://spring.io/projects/spring-cloud#learn)
### Spring Cloud生命周期

* [版本发布规划](https://github.com/spring-cloud/spring-cloud-release/milestones)
* [版本发布记录](https://github.com/spring-cloud/spring-cloud-release/releases)
* [版本终止声明](https://spring.io/projects/spring-cloud#overview)

### Spring Boot、Sping Cloud、Sping Cloud Alibaba的兼容性关系
* [版本说明官方文档](https://github.com/alibaba/spring-cloud-alibaba/wiki/%E7%89%88%E6%9C%AC%E8%AF%B4%E6%98%8E)
* Srping Cloud Alibaba正式发布（孵化成功）后版本兼容性可以在[Spring Cloud官方文档](https://spring.io/projects/spring-cloud#overview)中查看
* 下面是博主学习时候的版本列表

| Spring Cloud Version | Spring Cloud Alibaba Version | Spring Boot Version|
| :-: | :-: | :-: |
| Spring Cloud Greenwich |  2.1.0.RELEASE |  2.1.X.RELEASE |
| Spring Cloud Finchley |  2.0.0.RELEASE |  2.0.X.RELEASE |
| Spring Cloud Edgware |  1.5.0.RELEASE |  1.5.X.RELEASE |

### 生产环境怎样选择合适的版本

* 坚决不用非稳定版本/end-of-life版本
* 尽量用最新一代正式版本
	* xxx.RELEASE版本先缓一缓
	* SR2之后一般可以大规模使用（一般会比RELEASE版本晚半年左右）
