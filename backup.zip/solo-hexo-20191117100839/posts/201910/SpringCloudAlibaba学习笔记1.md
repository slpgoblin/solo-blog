title: Spring Cloud Alibaba 学习笔记 1
date: '2019-10-21 22:59:43'
updated: '2019-10-21 23:00:55'
tags: [SpringBoot, actuator, 笔记]
permalink: /articles/2019/10/21/1571669983427.html
---
![](https://img.hacpai.com/bing/20190820.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## Spring Boot监控之Actuator

**/health 健康检查**
http://localhost:8763/actuator/health
![image.png](https://img.hacpai.com/file/2019/10/image-fe1e79ef.png)

配置文件添加显示详情
```
# 输出 health 的详情
management:
  endpoint:
    health:
      show-details: always
```
* UP : 正常
* DOWN : 不正常
* OUT_OF_SERVICE : 资源未在使用，或不该被使用
* UNKNOWN  : 未知状态

**/info描述型端点**
一般应用于项目描述
http://localhost:8763/actuator/info
![image.png](https://img.hacpai.com/file/2019/10/image-4d1141fc.png)
如下配置文件添加显示详情，其中name、author
```
info:
  name: demo
  author: goblin
  email: goblin.com
```
**查看actuator所有端点**
默认actuator只有health和info是激活状态，想要查看其他端点需要添加如下配置
```
# 激活所有端点
management:
  endpoints:
    web:
      exposure:
        include: "*"
# 配置指定端点
management:
  endpoints:
    web:
      exposure:
        include: "metrics,health"
```
![image.png](https://img.hacpai.com/file/2019/10/image-31a9acb5.png)
这里说几个比较常用的

* actuator/configprops : 展示应用当前的配置属性，可以用来检查配置是否生效，比如jdk
* actuator/metrics : 度量端点，可以查看xxx属性的最大值，查看xxx状态
* actuator/beans : 查看应用程序上下文中的所有bean
* actuator/configprops : 查看@ConfigurationProperties的配置属性列表
* actuator/env : 查看环境变量
* actuator/loggers : 查看日志级别
* actuator/mappings : 显示所有资源路径(url)
