title: Spring Cloud Alibaba 学习笔记 10
date: '2019-10-30 09:12:01'
updated: '2019-10-30 09:12:01'
tags: [待分类]
permalink: /articles/2019/10/30/1572397921649.html
---
## 集成Nacos

### 搭建Nacos服务端
[下载Nacos](https://github.com/alibaba/nacos/releases)

版本可以根据Spring Cloud Alibaba的依赖中寻找nacos客户端的版本，如下：
```
        <nacos.client.version>1.1.1</nacos.client.version>

```

由于nacos服务端没有1.1.1，所以我是用的版本是1.1.3

搭建Nacos服务端

[官方文档](https://nacos.io/zh-cn/docs/quick-start.html)

启动成功后访问http://127.0.0.1:8848/nacos

账号密码是：nacos/nacos

### 用户中心注册到Nacos

### 内容中心注册到Nacos

### 验证
