title: Spring Cloud Alibaba 学习笔记 6
date: '2019-10-27 00:06:39'
updated: '2019-10-27 00:58:34'
tags: [JAVA, 笔记, SpringCloud, Alibaba]
permalink: /articles/2019/10/27/1572105999186.html
---
## 什么是Spring Cloud

* 快速构建分布式系统的工具集

| 功能 | 描述 | 可选择组件 |
| :-: | :-: | :-: |
| Distributed/versioned configuration | 分布式/版本化的配置管理 | Spring Cloud Config、Consul、**Nacos**、Zookeeper |
| Service registration and discovery | 服务注册与服务发现 | Eureka、Consul、**Nacos**、Zookeeper |
| Routing | 路由 | Zuul、**Spring Cloud Gateway** |
| Service-to-service calls | 端到端的调用 | **RestTemplate**、**Feign Ribbon** |
| Load balancing | 负载均衡 | **Ribbon** |
| Circuit Breakers | 断路器 | Hystrix、**Sentinel**、Resilience4J |
| Global locks | 全局锁 | Spring Cloud Cluster（已经迁移到Spring Integration） |
| Leadership election and cluster state | 选举与集群状态管理 | Spring Cloud Cluster（已经迁移到Spring Integration） |
| Distributed messaging | 分布式消息 | Spring Cloud Stream + Kafka/RabbitMQ/**RocketMQ** |

## 什么是Spring Cloud Alibaba
* Spring Cloud的子项目
* 包含微服务开发必备组件
* 基于Spring Cloud，符合Spring Cloud标准
* 阿里的微服务解决方案
## Spring Cloud Alibaba的主要功能
| 功能 | 产品 | 说明 |
| :-: | :-: | :-: |
| 服务注册发现 | Nacos | 开源组件 |
| 服务限流降级 | Sentinel<br>ANS | 开源组件<br>商业组件 |
| 分布式配置管理 | Nacos<br>ACM | 开源组件<br>商业组件 |
| 消息驱动能力 | Spring Cloud Stream、RocketMQ | 开源组件 |
| 分布式事务 | Seata | 开源组件，不能用于生产（目前0.61），1.0.0之后可用于生产 |
| 阿里云对象存储 | OSS | 商业组件 |
| 分布式任务调度 | SchedulerX | 商业组件 |
| 阿里云短信服务 | SMS | 商业组件 |
