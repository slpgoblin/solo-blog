title: Spring Cloud Alibaba 学习笔记 2
date: '2019-10-21 23:31:56'
updated: '2019-10-21 23:31:56'
tags: [SpringBoot, 笔记]
permalink: /articles/2019/10/21/1571671915988.html
---
## Spring Boot 配置
常用配置大概有四种方式
* 配置文件：properties、yml
* 环境变量 : 在配置文件中使用`value: ${VALUE_ENV}`。
![image.png](https://img.hacpai.com/file/2019/10/image-8ed9c1db.png)
![image.png](https://img.hacpai.com/file/2019/10/image-f2908fac.png)


* 外部配置文件 : springboot会默认读取jar包同级目录的配置文件，并且优先级高于jar包内部配置文件。
* 命令行参数 : java -jar server.port=8888

```
**这里穿插一个知识点**
如果项目使用mvn clean install构建失败报错是单元测试失败 。可以使用`mvn clean install -DskipTests`忽略单元测试
```
